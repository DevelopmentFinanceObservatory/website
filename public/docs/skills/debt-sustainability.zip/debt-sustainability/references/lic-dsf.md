# The LIC-DSF

What this covers: the joint IMF and World Bank Debt Sustainability Framework for Low-Income Countries, its ratings, the indicators and thresholds of the 2017 framework and of its 2026 review, and how closely public data approximate each indicator.

## Who it covers

The LIC-DSF applies to countries eligible for the IMF's concessional lending (the PRGT) that also have access to IDA resources, and to every country eligible for IDA grants. Countries that borrow on international markets stay under it while they meet those conditions.

## Ratings

Each DSA rates the risk of external debt distress in four levels. Low risk means no indicator breaches its threshold under the baseline or the stress tests. Moderate risk means the baseline stays within the thresholds and at least one stress test breaches them, and moderate ratings are graded further by the space to absorb shocks, as limited, some or substantial. High risk means a threshold is breached in the baseline. In debt distress means a distress event, such as arrears or a restructuring, has occurred or is imminent. The model's mechanical signals are combined with staff judgement, so a rating can differ from what the thresholds alone imply. DSAs also rate an overall risk of public debt distress, which adds domestic public debt, and the IMF's list carries the external rating.

For countries at high risk or in debt distress, the DSA also judges whether debt is sustainable or unsustainable.

## Debt-carrying capacity

Each country is classed as weak, medium or strong by a composite indicator, and the thresholds depend on the class. The 2017 composite weights the World Bank's CPIA score, real GDP growth, remittances, reserves and world growth. A country's class comes from its DSA.

## Indicators and thresholds

All thresholds are percentages, for weak, medium and strong capacity in turn. Present values use a 5% discount rate.

2017 framework, used for DSAs until the 2027 summer recess:

| Indicator | Weak | Medium | Strong |
| --- | --- | --- | --- |
| PV of external PPG debt / GDP | 30 | 40 | 55 |
| PV of external PPG debt / exports | 140 | 180 | 240 |
| External PPG debt service / exports | 10 | 15 | 21 |
| External PPG debt service / revenue excluding grants | 14 | 18 | 23 |
| PV of total public debt / GDP (benchmark) | 35 | 55 | 70 |

2026 framework, used for DSAs after the 2027 summer recess:

| Indicator | Weak | Medium | Strong |
| --- | --- | --- | --- |
| PV of external PPG debt / GDP | 30 | 40 | 55 |
| External PPG debt service / exports | 11 | 15 | 22 |
| External PPG debt service / revenue excluding grants | 16 | 18 | 24 |
| Face value of public debt / GDP | 55 | 65 | 75 |
| Gross financing needs / GDP | 12 | 14 | 16 |
| Interest on public debt / revenue excluding grants | 18 | 22 | 24 |

The first three rows of the 2026 table measure external public debt stress and the last three overall public debt stress. A DSA's thresholds depend on its date.

## The 2026 review

The IMF and World Bank staff paper reviewing the framework is dated 31 July 2026, and the IMF Executive Board discussed it on 9 September 2026. Its changes apply to DSAs issued after the 2027 summer recess.

- Terms. Ratings become the risk of external public debt stress and the risk of public debt stress, and "in debt distress" is kept. Earlier ratings stay in their 2017 terms.
- Assessments. External public debt stress, overall public debt stress and unsustainable public debt are assessed separately. A model-based signal of unsustainable debt is generated for countries at high risk or in debt distress, and neither the signal nor its cut-offs are published.
- High-risk ratings gain detail by time horizon and type of risk.
- Indicators. PV of external debt to exports is dropped, and three overall public debt indicators are added: face value of public debt to GDP, gross financing needs to GDP and interest to revenue excluding grants.
- Debt-carrying capacity. The composite drops world growth and adds output volatility and global financing conditions, measured as the interest rate on new external public debt times the external share of debt. The staff propose publishing each country's composite score every June and December once the framework is in full use.
- New modules cover domestic debt risk and long-term risks including climate adaptation, and a debt data confidence flag partly compares the DSA's public external debt with the World Bank's International Debt Statistics.

## Approximating the indicators from public data

| Indicator | Built from | How close |
| --- | --- | --- |
| External public debt service / exports | PPG debt service plus IMF repurchases and charges, over exports of goods and services | Close, the same measures as the DSA |
| External public debt service / revenue excluding grants | the same numerator, over revenue excluding grants as a share of GDP times GDP | Moderate, by revenue coverage |
| PV of external public debt / GDP | PPG debt plus IMF credit at face value, over GDP | Moderate, overstated for concessional debt |
| Face value of public debt / GDP | general government gross debt as a share of GDP | Moderate, by coverage |
| Interest / revenue excluding grants | net interest, the primary balance minus the overall balance, over revenue | Weak to moderate, net of interest received and with revenue coverage |
| Gross financing needs / GDP | needs domestic debt repayments | Not buildable |
| PV of external debt / exports | needs present values | Not buildable |

Debt-carrying capacity, present values and the unsustainability signal cannot be built from public data. With the class unknown, a ratio above the strong threshold is above the benchmark for every class, one below the weak threshold is below it for every class, and one in between depends on a class the data cannot give.
