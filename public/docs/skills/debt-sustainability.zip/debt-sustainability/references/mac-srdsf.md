# The MAC-SRDSF

What this covers: the IMF's Sovereign Risk and Debt Sustainability Framework for market-access countries, its ratings and sustainability judgement, what published reports include, the IMF's criteria for sovereign stress, the risk factors its models use, and what public data can show of them. The source is the IMF staff guidance note of July 2022.

## Who it covers

The framework covers IMF members that are not eligible for the IMF's concessional lending, and some eligible countries with substantial and durable market access. It assesses gross public debt, domestic and external, with general government as the default perimeter. Where domestic debt is the larger part, external debt data describe a minority of what the framework assesses.

## Ratings

The framework rates the risk of sovereign stress as low, moderate or high for the near term (one to two years), the medium term (up to five years) and the long term (beyond five years), plus an overall rating. Ratings start from model-based indices and staff judgement completes them. The framework sets no debt thresholds, so the same debt ratio can carry low risk in one country and high risk in another.

The near-term rating uses an early-warning model. The medium-term rating combines a fan chart of simulated debt paths with a module testing whether gross financing needs can be met, in which foreign private investors roll over only part of their holdings and domestic banks absorb the rest. A high-risk signal corresponds on average to a probability of stress of about 40% in the near term and 43% in the medium term, and as low as about 20%, so a high rating means roughly a one-in-five to two-in-five chance of stress. The long-term assessment covers demographics, natural resources, large amortisations and climate change where they apply.

The sustainability judgement has three outcomes: sustainable with high probability (at least 80%), sustainable but not with high probability (at least 50%), and unsustainable. It is required for DSAs under IMF arrangements and is optional and rare in surveillance-only cases.

## What published reports include

Published reports give the medium-term, long-term and overall ratings. The IMF removes the near-term assessment, the mechanical sustainability signal and the words "with high probability" before publication, keeping the last only where its lending policies require it, as in exceptional-access arrangements. The IMF's 2024 Transparency Policy review kept these deletions as temporary. A published "sustainable" therefore covers both the at-least-80% and at-least-50% cases. The near-term assessment is not produced at all for a country already in stress, including one in a non-precautionary IMF programme.

## Sovereign stress

The IMF counts a country as in sovereign stress when any one of these occurs:

- default: external arrears of at least 5% of public external debt and rising at least 10% in nominal terms, or default on domestic debt instruments
- a restructuring of repayment terms, excluding liability management operations
- a non-precautionary IMF programme with access above 100% of quota and disbursement in its first year, other IFI financing above 5% of GDP, or exceptional donor disbursement above 5% of external debt
- inflation that doubles and exceeds 25%, or exceeds 100%
- for emerging markets, sovereign spreads that double to at least 500 basis points
- loss of market access when there is a financing need
- financial repression, such as fast growth in central bank or commercial bank claims on government or large jumps in Treasury bill rates.

Public datasets show some of these: arrears against public external debt, inflation, and restructurings recorded as debt rescheduled or forgiven. A criterion met in the data matches the IMF's definition of stress, and the IMF's judgement is in its report.

## Risk factors the models use

The near-term early-warning model uses institutional quality (the World Governance Indicators for government effectiveness and regulatory quality), stress history, the current account balance to GDP, the three-year change in the real effective exchange rate, the credit-to-GDP gap, the change in public debt to GDP, public debt to revenue, foreign-currency public debt to GDP, international reserves to GDP and the change in the VIX.

Most of these can be shown from public data as trends and peer comparisons. The models combine them with weights and cut-offs that the IMF keeps confidential, so a score built from public data is not the IMF's. External public debt is a proxy for foreign-currency public debt that understates it where domestic debt is in foreign currency and overstates it where external debt is in local currency. Projections from the IMF World Economic Outlook approximate a DSA baseline. The IMF compares countries with emerging-market peers, split into commodity exporters and others, and peer medians follow the same split.

## Financing needs and debt holders

Gross financing needs are the primary deficit plus interest and amortisation, plus realised contingent liabilities, less interest revenue. Public data give the primary balance, external public debt service and its projections, including Eurobond maturities. Domestic debt repayments are usually the largest component and are missing from public data, so a public-data figure covers only some components.

The share of public debt held by foreign private creditors matters because the stress test assumes they pull back first. Bonds, commercial banks and other private creditors in external public debt, over total public debt, approximate it. Domestic bank holdings are missing from public data.
