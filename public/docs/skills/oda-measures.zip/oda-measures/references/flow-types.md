# Flow types

What this covers: the four ODA flow types reported by the OECD DAC, which questions each fits, ONE's usual choices, and the 2018 methodology break.

## When to use

This reference informs questions that turn on which ODA measure to use, what a specific figure such as "grant equivalents" means, how to compare ODA across donors or years, and why two ODA figures for the same donor or year differ.

## Concepts and definitions

Disbursements are actual payments made in a given year. They show the realisation of donor intentions and the implementation of policy, so they are the measure of ODA flows.

Gross disbursements are the total a donor disburses in a year, before subtracting loan repayments received from borrowers. Grant-equivalent data is not always available at activity level, so gross disbursements are the measure for detailed breakdowns by sector, recipient country or channel.

Net disbursements are gross disbursements minus loan repayments received in the same year. They show net resource transfers to a recipient, the amount a donor paid out beyond what it received back. They are negative when repayments in a year exceed new disbursements. For example, if Japan disbursed USD 5 billion in loans and received USD 3 billion in repayments, its net disbursements are USD 2 billion. They suit specific questions about resource transfers and are less common in detailed analysis.

Grant equivalents count only the concessional portion of a loan as ODA. A loan's grant equivalent is its disbursement multiplied by its grant element, the share of the loan that is a financial "gift" relative to a market loan. Grants count in full because their grant element is 100%. The grant element is calculated at commitment using income-differentiated discount rates and is not recalculated at disbursement. The DAC adopted the grant-equivalent methodology in 2014 to better reflect donor effort and to encourage more concessional lending to low-income countries. Grant equivalents are the measure for headline ODA figures and ODA/GNI ratios.

Commitments are the amount a donor formally agrees to provide, regardless of when it is paid. They measure donor intentions and allow monitoring of resource targeting. A commitment may be disbursed over several years, so commitments are a poor proxy for actual flows. For example, a donor that commits USD 200 million to a five-year infrastructure programme in 2022 records the commitment in 2022 and records disbursements each year as payments are made.

## The 2018 methodology break

Headline ODA uses grant equivalents from 2018 data, first reported in 2019, and earlier headline figures use the cash-flow methodology, so the two are not directly comparable. The OECD also publishes grant-equivalent figures for 2015–2017 and a parallel cash-flow series that is comparable across the full period. An analysis that spans 2018 can therefore use the cash-flow series throughout, stay on one side of the break, or span the break with a caveat.

## Choosing a flow type

Grant equivalents suit questions about aggregate donor effort and ODA/GNI, because they reflect the true cost to the donor of concessional loans. Gross disbursements suit questions about where ODA went, by sector, country or channel. A question that combines a headline figure with a granular breakdown can need a different measure for each part. Commitments suit questions about what donors intend to provide.

ONE generally uses grant equivalents for headline aggregates (total ODA and ODA/GNI) and gross disbursements for sector and recipient breakdowns, and uses disbursements rather than commitments for actual flows. Which measure fits depends on what the user wants to learn from the data, and a user's stated preference can differ from ONE's usual choice.

## Pitfalls

- Grant equivalents and gross disbursements in the same chart or table, without labels, lead readers to draw incorrect conclusions.
- Net disbursements used without explanation confuse readers who expect gross figures.
- Grant equivalents are a measurement concept applied to all ODA, including loans, and differ from grants, which are non-repayable transfers. A donor with a large loan portfolio has grant equivalents well below its gross disbursements.
- Two figures for the same donor that look different often reflect different flow types or different series (cash-flow and grant-equivalent) rather than a data error. The series a data source uses is not always obvious.

## What makes a result verifiable

A result is verifiable when it states its flow type and the reason for it, states which series the data uses, and flags the 2018 break when the analysis spans it. Where parts of an analysis use different measures, each part names its own.
