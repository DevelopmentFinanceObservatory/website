# Bilateral and multilateral ODA

What this covers: the structure of ODA flows from sovereign donors to recipients, the bilateral and multilateral distinction, and what earmarked funding means.

## Concepts and definitions

Bilateral ODA: Flows that go directly from a donor to a recipient country, or through a third party while staying under the donor's direction (earmarked or bi-multi). Core support to NGOs and public-private partnerships (PPPs) is also bilateral.

Earmarked funding (bi-multi): Bilateral ODA channelled through a multilateral organisation, with the donor specifying the sector, country, or purpose. It counts in total bilateral ODA.

Multilateral ODA (core contributions): Unearmarked contributions from donors to multilateral agencies on the OECD List of ODA-eligible international organisations. The multilateral decides the sector, purpose, and recipient.

Multilateral outflows: The funds that multilateral organisations disburse to recipients. They are the multilaterals' spending and the conduit for donors' core contributions.

List of ODA-eligible international organisations: The OECD list in Annex 2 of the DAC Reporting Directives, covering multilateral agencies, PPPs, and NGOs. Core funding counts as multilateral ODA only for listed multilateral agencies. Core support to a listed PPP or NGO is bilateral core support.

Channel of delivery: The first implementing partner, meaning the organisation with implementing responsibility over the funds, which is linked to the extending agency by a contract. The CRS codes name specific organisations, grouped into categories such as donor government, UN agency, World Bank Group, or NGO. The channel records the implementing organisation, while the bilateral or multilateral classification records the funding type. Bilateral ODA can go through an NGO, or through a multilateral as bi-multi.

## Terminology and scope

"Bilateral" and "multilateral" are used loosely outside the OECD framework. Many governments call any funding through a multilateral "multilateral", including earmarked funding, for example in their budgets. Under DAC rules, earmarked funding through a multilateral is bilateral ODA.

Whether bi-multi is counted within bilateral ODA, shown separately, or left out changes the totals, so the treatment is part of the definition of any figure.

## Where each flow is reported

Core multilateral contributions are reported in DAC1. The CRS also carries them as core-contribution records, which since the April 2026 release are ordinary records flagged as multilateral inflows. The CRS in the DFO knowledge graph filters those records out, so it holds bilateral ODA, including bi-multi, and the multilaterals' own outflows. Core contributions measure what a donor gives, while multilateral outflows measure what a multilateral spends.

## Pitfalls

Double counting bi-multi. Bi-multi sits inside total bilateral ODA, so a breakdown that shows it separately subtracts it from the bilateral total.

Funding that behaves like multilateral core support but is classified as bilateral. For example, CEPI is on the Annex 2 list as a PPP, with an 88% ODA coefficient from 2022, so its core funding is reported as bilateral core support. The Global Financing Facility (GFF) has no Annex 2 entry and contributions to it go through the World Bank as earmarked trust-fund money, so they are bi-multi. In both cases, pooled, flexible money governed by the fund's board counts as bilateral, which affects a donor's measured earmarked share and understates the quality of its multilateral engagement.

Treating multilateral outflows as the donor's ODA. A donor's core contribution to the World Bank is recorded in the year it is paid or, for contributions made in notes, the year the note is issued. The World Bank disburses to recipients over several years according to its own priorities.

## What makes a result verifiable

A result is verifiable when it states the definition of bilateral and multilateral in use, which flows count as bilateral, whether bi-multi is included within bilateral, shown separately or excluded, and whether core multilateral ODA is included in the figures. Where bi-multi is shown separately, the bilateral total excludes it. Contributions to funds such as CEPI or GFF are identified by their classification as bilateral core support or bi-multi.
