---
name: debt-ids
description: >-
  Context for working with the World Bank's International Debt Statistics (IDS), the external debt of low- and middle-income countries as reported by the borrowers. Covers its sources, the debt stocks, flows, debt service, net flows and net transfers it reports and how they relate, the creditor and borrower breakdowns, the DFO's version of the data, the conversion to US dollars, projections, revisions and underreporting, how IDS differs from creditor-side data such as the CRS, and how its series codes are built. Load once IDS has been chosen for an analysis, or when working with IDS figures.
license: CC-BY-4.0
---

# International Debt Statistics (IDS)

## What it is

IDS is the World Bank's annual dataset on the external debt of the countries that borrow from IBRD or IDA and report to its Debtor Reporting System, about 120 low- and middle-income countries, with the count varying by edition. External debt is debt owed to non-residents, and IDS records it from the debtor's side. Series start in 1970. IDS is updated every December with data to the end of the previous year. The annual publication is the International Debt Report, and the database is IDS.

## Where the figures come from

Long-term public and publicly guaranteed (PPG) debt is reported loan by loan by the borrowing government. Private non-guaranteed (PNG) debt is reported in aggregate, or estimated by World Bank staff where it is known to be large. Short-term debt comes mainly from the IMF and World Bank Quarterly External Debt Statistics and from BIS banking data. It includes interest arrears on long-term debt and on IMF credit, and it is a single figure covering public and private borrowers. IMF credit comes from the IMF.

Total external debt is the sum of long-term PPG debt, long-term PNG debt, use of IMF credit and short-term debt. The IMF component includes SDR allocations from 1999 and is separate from multilateral PPG debt.

## Measures and how they relate

The stock is debt outstanding and disbursed at year end. The flows are disbursements, principal repayments and interest. Debt service is principal plus interest, and total debt service also includes interest on short-term debt and repurchases and charges to the IMF. Net flows are disbursements minus principal repayments, and net transfers are net flows minus interest. A negative net transfer means the country pays its creditors more than it receives from them.

Disbursements and principal repayments are reported for long-term debt and IMF credit. Short-term debt has only a net flow, derived from the change in its stock, so net flows on total external debt combine long-term flows, IMF purchases minus repurchases and that short-term change.

IDS also reports commitments, undisbursed debt, principal and interest arrears, and amounts rescheduled or forgiven. The average interest rate, maturity, grace period and grant element describe new PPG commitments.

IDS counts debt as concessional when its original grant element is at least 35%, and loans from the World Bank and major regional development banks count as concessional under each lender's own classification. The debt-concepts skill compares this with the OECD's definition.

## Projections

Each release adds about eight years of projections after the last reported year, for long-term debt service, principal, interest and disbursements, and for IMF repurchases and charges. Stocks and short-term debt service are not projected, and the DFO marks the projected years as estimated. The projections are the contractual schedules of loans already signed, so they describe how existing debt runs off and carry no new borrowing. Projected disbursements are the undisbursed balance of those loans and fall towards zero within three or four years. Projected interest and debt service fall as the existing debt is repaid. A falling projected path is therefore an artefact of the data rather than a forecast of lower payments, and projected net flows and net transfers turn negative by construction. For a country that keeps borrowing, projected debt service is a floor on what it will pay, and prepayments, refinancing, rescheduling or cancellations change it.

## Creditors and double counting

PPG debt splits by creditor type into multilateral, bilateral, bondholders, commercial banks and other private creditors. PNG debt splits only into bonds and into commercial banks and other creditors. A creditor-type share of PPG debt is a different figure from a share of total external debt.

Figures by named creditor, such as China or a multilateral bank, go back decades. Confidentiality can fold a single creditor into "other bilateral" or "other multilateral". A creditor breakdown sits alongside an all-creditors total, so a sum that includes the total with its creditors counts the debt twice.

Regional and income-group aggregates are summed from the reporting countries using current classifications for every year. Guyana reports to IDS but is outside the low- and middle-income aggregates.

## In the DFO

Each figure is reported by year, debtor and, where there is one, creditor. Named dimensions include the type of flow, maturity, creditor type, guarantee status, debtor sector, concessionality and currency. Amounts are in current US dollars, in units of one dollar. Ratios are shares of GNI, of exports of goods, services and primary income, of total external debt or, for currency composition, of PPG debt, and debt per capita divides by population. A ratio for one creditor divides by the amount owed to that same creditor.

A series reported both as a total and by creditor appears as two variables, the total with no creditor and the breakdown by creditor. Lenders that IDS reports as series of their own (the IMF, IBRD, IDA, EBRD and IFC) appear as creditors, including where the source has only the total for them.

The DFO version covers the debt series, the grant and technical cooperation grant series, and GNI and exports as ratio denominators. It excludes population, the other non-debt context series, the present value of debt, annual changes in stocks and in interest arrears, debt forgiveness grants and the stock-flow residual. Zeros are kept on totals and within or after a period of lending between a debtor and a creditor. A missing creditor-debtor value can therefore be an unreported figure or a zero outside a lending period.

## Particularities

Stocks are converted to US dollars at year-end exchange rates and flows at annual average rates. A change in the debt stock differs from net flows because of cross-currency valuation, changes in interest arrears, capitalised interest and debt forgiveness. New borrowing is measured by net flows.

Each release revises history, often by adding debt that earlier releases missed, so figures depend on the release. For some countries the World Bank estimates the figures in the absence of a report.

Debt owed to lenders outside the Paris Club, including China, and debt of state-owned enterprises, special purpose vehicles and collateralised loans are underreported, according to World Bank research. A single-creditor figure is best read as a lower bound.

## IDS and the CRS

IDS is the debtor's record of all its external debt, from every creditor and on any terms. The OECD CRS is the creditor's record of the development finance it provides, as commitments and disbursements. The two cover different flows from opposite sides and do not reconcile.

## References

- [references/series-codes.md](references/series-codes.md) — how IDS series codes are built, what each code segment means, the code-level traps, and how codes map to the DFO's named dimensions
